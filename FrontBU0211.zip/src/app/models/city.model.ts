export class CityModel {
    public city: string;
    public population: string;
}

export default CityModel;