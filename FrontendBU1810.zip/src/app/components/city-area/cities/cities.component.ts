// import { HttpClient } from '@angular/common/http';
// import { Component, OnInit } from '@angular/core';
// import CityModel from 'src/app/models/city.model';

// @Component({
//   selector: 'app-cities',
//   templateUrl: './cities.component.html',
//   styleUrls: ['./cities.component.css']
// })
// export class CitiesComponent implements OnInit {

//   public cities: CityModel[];
//   public list: CityModel[];
  
//   constructor(private http: HttpClient) { }

//   async ngOnInit() {
//         this.cities = await this.http.get<CityModel[]>("https://raw.githubusercontent.com/royts/israel-cities/master/israel-cities.json").toPromise(); 
//         // this.list = JSON.parse(this.cities);         
//     }
// }
