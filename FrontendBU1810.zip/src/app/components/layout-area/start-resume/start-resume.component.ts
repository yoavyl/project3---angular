import { Component, Input, OnDestroy, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Unsubscribe } from 'redux';
import CartItemModel from 'src/app/models/item.model';
import UserModel from 'src/app/models/user.model';
import store from 'src/app/redux/store';

@Component({
  selector: 'app-start-resume',
  templateUrl: './start-resume.component.html',
  styleUrls: ['./start-resume.component.css']
})
// export class StartResumeComponent implements OnInit, OnDestroy {

    export class StartResumeComponent  {

//   public user: UserModel;
  public isAdmin: boolean;
  private unsubscribeMe: Unsubscribe;

  @Input()
  public carts: CartItemModel[];

  @Input()
  public openCart: boolean;

  constructor( private router: Router) {}

  public isNotHome() {
    const h = this.router.url.includes("/home");
    return !h
}

}

