import { Component, OnInit } from '@angular/core';
import { SplitterType } from 'igniteui-angular';
import { Subscription } from 'rxjs';
import ProductModel from 'src/app/models/product.model';
import { NotifyService } from 'src/app/services/notify.service';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public typeHorizontal = SplitterType.Horizontal;

  public products: ProductModel[];
  public addRequest: boolean = false;
  public product = new ProductModel();

  private subscriptionAdd: Subscription;
  private subscriptionUpdate: Subscription;

  constructor(private myProductsService: ProductsService, private notify: NotifyService) {
    
    this.subscriptionAdd = this.myProductsService.getCartObservable().subscribe(product => {
      if (product.product.ProductID>0) {
          this.addRequest = false;
      } else {
        this.addRequest = !this.addRequest
          // clear messages when empty message received
          // this.messages = [];
      }
    });

   }

  async ngOnInit() {
      try {
          this.products = await this.myProductsService.getAllProducts();
      }
      catch (err) {
          this.notify.error(err);
      }
  }

  public add() {
    this.product.ProductID = 0;
    this.myProductsService.adminProductUpdate(this.product);
  }

}
