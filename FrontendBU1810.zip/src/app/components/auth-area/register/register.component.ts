import { Component } from '@angular/core';
import { Router } from '@angular/router';
import CityModel from 'src/app/models/city.model';
import { UserModel } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { CityService } from 'src/app/services/city.service';
import { NotifyService } from 'src/app/services/notify.service';
import { UserService } from 'src/app/services/users.service';


// @NgModule({
//     //..your other property,
//        schemas: [CUSTOM_ELEMENTS_SCHEMA]
//      })

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent {

    public user = new UserModel();
    public step: boolean = false;
    public passExists: boolean = false;
    public emailExists: boolean = false;
    public users: UserModel[];
    private passMatch: number;
    private emailMatch: number;
    public cities: CityModel[];

    constructor(
        private myAuthService: AuthService,
        private myUserService: UserService,
        private myCityService: CityService,
        private notify: NotifyService,
        private myRouter: Router) { }

        async ngOnInit() {
            try {
                this.cities = await this.myCityService.getAllCities();
            }
            catch (err) {
                this.notify.error(err);
            }
        }

    public async register() {
        try {
            await this.myAuthService.register(this.user);
            this.notify.success("You are registered :-)");
            this.myRouter.navigateByUrl("/home");
        }
        catch(err) {
            // לבטל את זה,כי כל ההודעות הן בתחתית
            this.notify.error(err);
        }
    }

    public async continue() {
        try {
            this.users = await this.myUserService.getAllidcardsEmails();
            this.passMatch = this.users.findIndex(item => item.idcard === this.user.idcard)
            this.emailMatch = this.users.findIndex(item => item.email === this.user.email)
            if (this.passMatch<0 && this.emailMatch<0) { this.step = true; }
            if (this.passMatch>=0) { this.passExists = true; }
            if (this.emailMatch>=0) { this.emailExists = true; }
        }
        catch (err) {
            this.notify.error(err);
        }
    }

    // onFocus() {
    //     if (this.passExists) {this.passExists = false}
    //     if (this.con) {this.con = false}
    //     if (this.con2) {this.con2 = false}

    

    back() {
        this.step = false;
    }

    // check(){
    //     this.con=true;
    // }

    // check2(){
    //     this.con2=true;
    // }
}
