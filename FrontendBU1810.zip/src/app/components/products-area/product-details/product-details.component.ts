import { ProductsService } from './../../../services/products.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import ProductModel from 'src/app/models/product.model';
import { NotifyService } from 'src/app/services/notify.service';
import { environment } from 'src/environments/environment';
import { MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { OrderUnitsDialogComponent } from '../../order-area/order-units-dialog/order-units-dialog.component';



// imports: [MatDialogModule]

export interface DialogData {
    [x: string]: string;
    // quantity: number;
  }


@Component({
    selector: 'app-product-details',
    templateUrl: './product-details.component.html'
})
export class ProductDetailsComponent implements OnInit {

    public product: ProductModel;

    public quantity: number;

    public imageUrl = environment.productImagesUrl;

    constructor(
        private myActivatedRoute: ActivatedRoute,
        public dialog : MatDialog,    //  for dialog!!!
        // private modalService: NgbModal,
        private notify: NotifyService,
        private myRouter: Router,
        private myProductsService: ProductsService) { }

    async ngOnInit() {
        try {
            const id = +this.myActivatedRoute.snapshot.params.id; // Take a route parameter named id.
            this.product = await this.myProductsService.getOneProduct(id);
        }
        catch (err) {
            this.notify.error(err);
        }
    }

    public openDialog() {
        const dialogRef = this.dialog.open(OrderUnitsDialogComponent,  {
            data: {quantity: this.quantity}
        });
    dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            this.quantity = result;
            console.log(this.quantity)
        });
    }
    

    public async delete() {
        try {
            const answer = confirm("Are you sure?");
            if (!answer) return;
            await this.myProductsService.deleteProduct(this.product.ProductID);
            this.notify.success("Product has been deleted.")
            this.myRouter.navigateByUrl("/products");
        }
        catch (err) {
            this.notify.error(err);
        }
    }

}


