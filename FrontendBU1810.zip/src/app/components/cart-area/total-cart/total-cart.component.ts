import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CartsService } from 'src/app/services/carts.service';

@Component({
  selector: 'app-total-cart',
  templateUrl: './total-cart.component.html',
  styleUrls: ['./total-cart.component.css']
})
export class TotalCartComponent implements OnInit {

  @Input()
  public totalCart: number;

  private subscription: Subscription;

  constructor(private myCartService: CartsService) {
    
    this.subscription = this.myCartService.getCartOpenObservable().subscribe(message => {
      if (message) {
          // this updates all the cards!!! in one subscription i update them all!!
          this.totalCart = message.totalCart;
          console.log("total cart in total cart app");
          console.log(message.totalCart);
      } else {
          // this.openCart = true;
          // console.log("open cart was closed?");
          // console.log("open cart? " + this.openCart);
      }
      
  })
   }

  ngOnInit(): void {
  }

}
