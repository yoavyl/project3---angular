import { Component, Input, OnInit } from '@angular/core';
import CartModel from 'src/app/models/cart.model';
import ItemModel from 'src/app/models/item.model';
import UserModel from 'src/app/models/user.model';
import { CartsService } from 'src/app/services/carts.service';
import { ItemService } from 'src/app/services/item.service';
import { NotifyService } from 'src/app/services/notify.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-item-card',
  templateUrl: './item-card.component.html',
  styleUrls: ['./item-card.component.css']
})
export class ItemCardComponent {
  @Input()
  public item: ItemModel;

  @Input()
  public items: ItemModel[];

  @Input()
  public cart: CartModel[];

  public imageUrl = environment.productImagesUrl;

  @Input()
  searchQuery: string = '';

  @Input()
  deleteItem: Function;

  @Input()
  getLastCart: Function;

  @Input()
  user: UserModel;

  constructor(private myItemService: ItemService,
    private myCartService: CartsService,
    private notify: NotifyService) {}

  // addToCart(): void {
  //     // send message to subscribers via observable subject
  //     this.productService.addToCart(this.product, 1);
  // }this.myItemService.deleteItem(id);


  // async deleteItem1(id: number) {
  //   try {
  //     const answer = confirm("Are you sure you want to remove this item?");
  //     if (!answer) return;
  //     await 
  //     // to delete it from screen in real time
  //     const index = this.items.findIndex(p => p.ItemID === id);
  //       this.items.splice(index, 1);
  //     console.log("cart items after 1 delete");
  //     console.log(this.items);
  //     this.notify.success("Item has been removed from cart.");
  //     // this.totalCart = this.myItemService.totalCartPerUser(this.items); // to send it to menu!!!!
  //     // then it send an automatic request to get GET all cart items, and then if it's empty already it's deleted...
  // }
  // catch (err) {
  //   // if (!this.cartItems) { await this.myCartService.deleteCart(this.cart[0].CartID)};
  //     this.notify.error(err);
  // }

  // // מה קורה אם מחקתי את הפריט האחרון? צריך למחוק את העגלה?
  // console.log("items length: " + this.items.length)
  // if (this.items.length === 0) { 
  //   await this.myCartService.deleteCart(this.cart[0].CartID);
  //   this.myCartService.cartIsClosed(true); // notifies produst card that cart is closed
  //   // this.getLastCart(); // menu needs to do that!!!!
  // };
  // // if (this.cartItems.length === 0) {this.deleteCart(this.cart[0].CartID)};

  // }
}
