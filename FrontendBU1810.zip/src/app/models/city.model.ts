export class CityModel {
    // public semel_yeshuv: number | string;
    // public name: string;
    // public english_name: string;
    // public semel_napa: number | number;
    // public shem_nap: string;
    // public semel_lishkat_mana: number;
    // public lishka: string;
    // public semel_moatza_ezorit: number;
    // public shem_moaatza: string;
    public city: string;
    public population: string;
}

export default CityModel;