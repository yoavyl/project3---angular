const runSQL = require("./db-access");
const fs = require("fs");
const UserModel = require("../models/user-model");
const path = require("path"); 

// WITH MY SQL
async function getAllUUIDandEmails() {
    const results = await runSQL(`SELECT UserUUID, Email FROM users`)   
    return results;
}

async function getAllUserDetails(uuid) {                    // usesd "internally" by node js server to get user's details for order receipt
    const results = await runSQL(`SELECT * FROM users WHERE UserUUID="${uuid}"`)   
    return results;
}

module.exports = {
    getAllUUIDandEmails,
    getAllUserDetails,
}

