class ContactUsModel {
    public name: string;
    public email: string;
    public message: string;
}

export default ContactUsModel;