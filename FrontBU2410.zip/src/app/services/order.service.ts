import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import OrderModel from '../models/order.model';
import { orderAddedAction, ordersDownloadedAction } from '../redux/order-state';
import store from '../redux/store';
import { TimezoneService } from './timezone.service';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient, private tz_helper: TimezoneService) { }

  public async getOrderFile(fileName: string) {
        return await this.http.get(environment.ordersPDFUrl + fileName, { responseType: 'blob'}).toPromise();           
  }

    // Get all orders: 
    public async getAllOrdersByOrderIdDesc() {
        if (store.getState().orderState.orders.length === 0) {
            const orders = await this.http.get<OrderModel[]>(environment.ordersUrl).toPromise();           
            store.dispatch(ordersDownloadedAction(orders));

        }
        return store.getState().orderState.orders;
    }

    public async countOrders() {
      // NO REDUX?
      const count = await this.http.get<[]>(environment.ordersUrl + "count").toPromise();
      return count;
    }

    public async getFullyBookedDates() { // NO REDUX
      const count = await this.http.get<[]>(environment.ordersUrl + "count/dates").toPromise();
      return count;
    }

    // Get carts per user: --> never from redux!!!
    public async getLastOrderByUser(uuid: string) { // NEVER FROM REDUX
      // if (store.getState().orderState.orders.length === 0) {
        const orders = await this.http.get<OrderModel[]>(environment.ordersUrl + "user/" + uuid).toPromise();
          // Iterate over all employees and convert timezone to my local timezone
        for (let order of orders) {
          order.Date = this.tz_helper.convertTZ(order.Date).toString(); 
        }
          store.dispatch(ordersDownloadedAction(orders));
      // }
          // NEED TO UNDERSTAND IF THAT IS CORRECT
    // const orders = store.getState().orderState.orders.filter(p => p.UserUUID === uuid);
    return orders;
    }
    
    // // Get one employee: 
    // public async getOneEmployee(id: number) {
    //     if (store.getState().employeesState.employees.length === 0) {
    //         const employees = await this.http.get<EmployeeModel[]>(environment.employeesUrl).toPromise();
    //         employees[0].BirthDate = this.tz_helper.convertTZ(employees[0].BirthDate).toString(); 
    //         store.dispatch(employeesDownloadedAction(employees));
    //     }
    //     const employee = store.getState().employeesState.employees.find(p => p.id === id);
    //     return employee;
    // }

    // // Add order: 
    public async addOrder(order: OrderModel) {
      console.log(order);
        const myFormData: FormData = OrderModel.convertToFormData(order);
        console.log(myFormData);
        const addedOrder = await this.http.post<OrderModel>(environment.ordersUrl, myFormData).toPromise();
        store.dispatch(orderAddedAction(addedOrder));
        return addedOrder;
    }

    // // Update employee: 
    // public async updateEmployee(employee: EmployeeModel) {
    //     const myFormData: FormData = EmployeeModel.convertToFormData(employee);
    //     const updatedEmployee = await this.http.put<EmployeeModel>(environment.employeesUrl + employee.id, myFormData).toPromise();
    //     store.dispatch(employeeUpdatedAction(updatedEmployee));
    //     return updatedEmployee;
    // }

    // // Delete employee: 
    // public async deleteEmployee(id: number) {
    //     await this.http.delete(environment.employeesUrl + id).toPromise();
    //     store.dispatch(employeeDeletedAction(id));
    // }

}