import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Unsubscribe } from 'redux';
import CartModel from 'src/app/models/cart.model';
import ItemModel from 'src/app/models/item.model';
import OrderModel from 'src/app/models/order.model';
import UserModel from 'src/app/models/user.model';
import store from 'src/app/redux/store';
import { NotifyService } from 'src/app/services/notify.service';
import { OrderService } from 'src/app/services/order.service';


@Component({
  selector: 'app-cart-home',
  templateUrl: './cart-home.component.html',
  styleUrls: ['./cart-home.component.css']
})

export class CartHomeComponent {

  @Input()
  public totalCart: number;

  @Input()
  public items: ItemModel[];

  @Input()
  public orders: OrderModel[];

  @Input()
  public user: UserModel;

  @Input()
  public openCart: boolean;

  @Input()
  public cart: CartModel[];

  constructor(private myOrdersService: OrderService, private notify: NotifyService) {}


}
