class EmployeeModel {
    public id: number;
    public FirstName: string;
    public LastName: string;
    public Title: string;
    public Country: string;
    public City: string;
    public BirthDate: string;
    public PhotoPath: string;
    public image: FileList;

    public static convertToFormData(employee: EmployeeModel): FormData {
        const myFormData = new FormData();
        myFormData.append("firstName", employee.FirstName);
        myFormData.append("lastName", employee.LastName);
        myFormData.append("title", employee.Title);
        myFormData.append("country", employee.Country);
        myFormData.append("city", employee.City);
        myFormData.append("birthDate", employee.BirthDate);
        if(employee.image) myFormData.append("image", employee.image.item(0));
        return myFormData;
    }
}

export default EmployeeModel;