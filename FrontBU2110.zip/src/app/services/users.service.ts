import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import UserModel from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

    // Get all users: 
    public async getAllidcardsEmails() {
        // i don't use redux here coz i don't want to save them because of sensitivity
        // this is why in the backend i select only the relevant column
        const users = await this.http.get<UserModel[]>(environment.usersUrl).toPromise();           
        return users;
    }

    // // Get one employee: 
    // public async getOneEmployee(id: number) {
    //     if (store.getState().employeesState.employees.length === 0) {
    //         const employees = await this.http.get<EmployeeModel[]>(environment.employeesUrl).toPromise();
    //         employees[0].BirthDate = this.tz_helper.convertTZ(employees[0].BirthDate).toString(); 
    //         store.dispatch(employeesDownloadedAction(employees));
    //     }
    //     const employee = store.getState().employeesState.employees.find(p => p.id === id);
    //     return employee;
    // }

    // // Add employee: 
    // public async addEmployee(employee: EmployeeModel) {
    //     const myFormData: FormData = EmployeeModel.convertToFormData(employee);
    //     const addedEmployee = await this.http.post<EmployeeModel>(environment.employeesUrl, myFormData).toPromise();
    //     store.dispatch(employeeAddedAction(addedEmployee));
    //     return addedEmployee;
    // }

    // // Update employee: 
    // public async updateEmployee(employee: EmployeeModel) {
    //     const myFormData: FormData = EmployeeModel.convertToFormData(employee);
    //     const updatedEmployee = await this.http.put<EmployeeModel>(environment.employeesUrl + employee.id, myFormData).toPromise();
    //     store.dispatch(employeeUpdatedAction(updatedEmployee));
    //     return updatedEmployee;
    // }

    // // Delete employee: 
    // public async deleteEmployee(id: number) {
    //     await this.http.delete(environment.employeesUrl + id).toPromise();
    //     store.dispatch(employeeDeletedAction(id));
    // }

}